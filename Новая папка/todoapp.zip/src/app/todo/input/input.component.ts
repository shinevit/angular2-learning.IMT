import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.css']
})
export class InputComponent implements OnInit {

  @Input()
  todoText: string = '';

  @Output()
  addNewTodoEmiter = new EventEmitter<string>();


  constructor() { }


  ngOnInit() {
  }


  onChangeInput(evt) {
    this.todoText = evt.target.value;
  }

  onAddBtnClick() {
    this.addNewTodoEmiter.emit(this.todoText);
    this.todoText = ' ';
  }

}
