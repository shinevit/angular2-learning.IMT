import { Component, OnInit, Input } from '@angular/core';
import { TodoItem } from '../todo-item/TodoItem';
import { TodoStateEnum } from '../todo-item/TodoStateEnum';

const MockData = [
  {text: 'Take out of garbage'},
  {text: 'Whash up'},
  {text: 'Shopping'}
];

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {

  items = new Array<TodoItem>();


  constructor() {
    let counter = 0;
    for (const item of MockData) {
      counter++;
      const todoItem = new TodoItem(item.text);
      todoItem.id = counter;
      this.items.push(todoItem);
    }
  }

  ngOnInit() {

  }

  onAddNewTodo(newTodoTxt) {
    this.addNewItem(new TodoItem(newTodoTxt));
  }

  addNewItem(item: TodoItem) {
    console.log('add item');

    this.items.push(item);
  }

  deleteItem(item: TodoItem) {
    console.log('delete item');
  }

  changeState(item: TodoItem) {
    console.log('item clicked');

    item.status = TodoStateEnum.Completed;
  }

}
