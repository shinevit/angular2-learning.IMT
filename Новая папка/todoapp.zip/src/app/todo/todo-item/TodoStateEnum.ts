export enum TodoStateEnum {
  New, Completed
}
