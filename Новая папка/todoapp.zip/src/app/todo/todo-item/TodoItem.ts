import { TodoStateEnum as TodoState} from './TodoStateEnum';

export class TodoItem {

  id: number;
  description: string;
  status: TodoState = TodoState.New;

  constructor(description: string) {
    this.description = description;
    this.id = 1;
  }


  get toString(): string {
    return `TodoItem: id=${this.id}, description: ${this.description}, status:{${this.status.toString()} (${this.status as number})}`;
  }
}
