import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  @Output("onNewTodo")
  onNewTodoEmiter = new EventEmitter<string>();

  constructor() { }

  ngOnInit() {
  }


  onAddNewTodo(text) {
    this.onNewTodoEmiter.emit(text);
    console.log(`at TodoComponent ${text}`);
  }
}
